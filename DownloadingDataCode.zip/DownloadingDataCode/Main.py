# -*- coding: utf-8 -*-

# --- DATAFRAME VALENBISI --- #
# Date
# Weekday -> No
# Is_holiday
# T_min - T_mean - T_max -> No
# Prec
# Vel_mean - Vel_max -> No
# Hour - Quarter - Timestamp
# Id_station - Bikes - Slots - Capacity - Predicted
# Latitude - Longitude

# Modules import
from DownloadZips import DownloadZips
from DownloadHolidays import DownloadHolidays
from DownloadWeather import DownloadWeather
from ExtractDataFromZips import ExtractDataFromZips
from ModifyCsvs import ModifyCsvs
from JoinValenbisi import JoinValenbisi
from Distances import Distances
from Probabilities import CreateProbMatrix
from Frequencies import CreateFreqCsv

# Process execution
if __name__ == "__main__":
    DownloadZips()
    DownloadHolidays()
    DownloadWeather()
    ExtractDataFromZips()
    ModifyCsvs()
    JoinValenbisi()
    Distances()
    CreateProbMatrix()
    CreateFreqCsv()