# -*- coding: utf-8 -*-

from AuxiliarFunctions import CreateFolder
import time
import pandas as pd
import random

def CreateFreqCsv():
    # Initial point:
    # Final point:
        
    # Starting time
    t0 = time.time()
    print("Step 9:")
    
    random.seed(4)
    CreateFolder("FrequencyData")
    df = pd.read_csv("../ValenbisiData/Valenbisi.csv", sep=";")
    df = (df.groupby(["Prec", "Is_holiday", "Period", "Id_station"])
          .size().reset_index().rename(columns={0: "Count"}))
    N = len(df)
    
    df["A"] = [random.randint(1, 20) for x in range(N)]
    df["B"] = 6
    period_values = {
        'Twelve': 20,
        'Night': 1,
        'Day': 10,
        'Evening': 5
    }    
    df['C'] = df['Period'].map(period_values)
    df["D"] = df["Is_holiday"].apply(lambda x: 5 if x else 7)
    df["E"] = df["Prec"].apply(lambda x: 1 if x else 8)
    
    df.to_csv("../FrequencyData/Frequency.csv", sep=";", index=False)
    
    # Final time
    t1 = time.time()
    print(f"\tCreating frequencies matrix time: {round(t1-t0,4)}s")
    
    return df

if __name__ == "__main__":
    df = CreateFreqCsv()