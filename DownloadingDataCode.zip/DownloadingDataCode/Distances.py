# -*- coding: utf-8 -*-

# Auxiliar functions
import AuxiliarFunctions as af

# Time management
import time

# File system management
import os

# Dataframes and csvs management
import pandas as pd

# Graph and distances management
import osmnx as ox
from osmnx.distance import nearest_nodes

def Distances():
    # Initial point: Valenbisi csv in ValenbisiData folder
    # Final point: 2 distances csvs in DistancesData folder
    
    def distance2Points(g, lat1, lon1, lat2, lon2):
        # Calculates the route given 2 nodes
        def CalculateRoute(n1, n2):
            return ox.shortest_path(g, n1, n2, weight = "length")
        
        # Calculates the distance given a route
        def SumEdges(r):
            return int(sum(ox.utils_graph.get_route_edge_attributes(g, r, attribute = "length")))
        
        n1 = nearest_nodes(g, lon1, lat1)
        n2 = nearest_nodes(g, lon2, lat2)
            
        try:
            return SumEdges(CalculateRoute(n1, n2))
        except:
            try:
                print("\tOrder changed")
                return SumEdges(CalculateRoute(n2, n1))
            except:
                print("\tUsing walking distances")
                return distance2Points(G["Walking"], lat1, lon1, lat2, lon2)
    
    # Starting time
    t0 = time.time()
    print("Step 7:")
    
    af.CreateFolder("DistancesData")
    
    if not os.path.exists("../DistancesData/DistancesWalking.csv"):
        print("\tExpected time: 5h")
        
        # Creates Stations dataframe
        df = pd.read_csv("../ValenbisiData/Valenbisi.csv", delimiter=";")
        df = df.groupby("Id_station").agg({"Latitude": "first", "Longitude": "first"})
        N = len(df)
        
        # Bounding box coordinates
        north, south = max(df["Latitude"]) + 0.001, min(df["Latitude"]) - 0.001
        east, west = max(df["Longitude"]) + 0.001, min(df["Longitude"]) - 0.001
        
        # Creates the graph
        G = {"Walking": ox.graph.graph_from_bbox(north, south, east, west, network_type='walk'),
             "Cycling": ox.graph.graph_from_bbox(north, south, east, west, network_type='bike')}
        
        # Distances dataframes
        distances = {"Walking": pd.DataFrame(0, index = range(1, N+1), columns = range(1, N+1)),
                     "Cycling": pd.DataFrame(0, index = range(1, N+1), columns = range(1, N+1))}
        
        # Dataframe iteration
        for id1, (lat1, lon1) in df.iterrows():
            for id2, (lat2, lon2) in df.iterrows():
                if id2 > id1:
                    for mode, dfDist in distances.items():
                        dist = distance2Points(G[mode], lat1, lon1, lat2, lon2)
                        dfDist.loc[id1, id2] = dist
                        dfDist.loc[id2, id1] = dist
        
        # Save dataframes
        for mode, dfDist in distances.items():
            dfDist.to_csv(f"../DistancesData/Distances{mode}.csv", sep = ";", index_label = "Index")    
    
    # Final time
    t1 = time.time()
    print(f"\tDistances matrix creation time: {round(t1-t0,4)}s")