# -*- coding: utf-8 -*-

from AuxiliarFunctions import CreateFolder
import time
import numpy as np
import os
import pandas as pd

N = 276

def CheckForMatrix(name, path = "../ProbabilityData/"):
    return os.path.exists(f"{path}{name}.npy")

def SaveMatrix(m, name, path = "../ProbabilityData/"):
    np.save(f"{path}{name}.npy", m)

def ReadDistancesCsv(name):
    return pd.read_csv(f"../DistancesData/Distances{name}.csv",
                     sep = ";", index_col = "Index", dtype = {"Index":str})

def CreateProbMatrix():
    # Initial point:
    # Final point:
        
    # Starting time
    t0 = time.time()
    print("Step 8:")
    
    CreateFolder("ProbabilityData")
    EqualProb()
    WalkingAndNearestProb("Walking")
    WalkingAndNearestProb("Nearest")
    Less30MinsDuration()
    
    # Final time
    t1 = time.time()
    print(f"\tCreating probability matrix time: {round(t1-t0,4)}s")

def EqualProb():
    name = "Equal"
    if not CheckForMatrix(name):
        m = np.full((N, N), 1/(N-1))
        np.fill_diagonal(m, 0)
        SaveMatrix(m, name)

def WalkingAndNearestProb(name):
    if not CheckForMatrix(name):
        df = ReadDistancesCsv("Cycling" if name == "Nearest" else "Walking")
        m = np.zeros((N, N), dtype = float)
        for i, row in df.iterrows():
            s = row.nsmallest(4)
            for j, d in s.items():
                m[int(i)-1, int(j)-1] = d/sum(s)
        SaveMatrix(m, name)

def Less30MinsDuration():
    name = "Less30MinsDuration"
    if not CheckForMatrix(name):
        CYCLING_SPEED = 265 # m/min
        m = np.genfromtxt("../DistancesData/DistancesCycling.csv", delimiter = ";",
                          dtype = int, skip_header = 1, usecols = range(1, N+1))
        m = m < CYCLING_SPEED * 30
        np.fill_diagonal(m, 0)
        m = np.where(m == 1, 1/np.sum(m, axis=1)[:, None], m)
        SaveMatrix(m, name)  