# -*- coding: utf-8 -*-

from AuxiliarFunctions import H,Q
import random
import numpy as np
import pandas as pd

SPEED = {"Walking": 92, "Cycling": 265} # m/min

DISTANCES = {k:pd.read_csv(f"../DistancesData/Distances{k}.csv",
                           sep = ";",
                           index_col = "Index",
                           dtype = {"Index":str}) for k in SPEED}

PROBABILITIES = pd.DataFrame([(x, w, c, n) for l, w, c, n in
                              [[range(1,32,5), "Equal",      "Equal",                "Equal"],
                               [range(2,33,5), "Walking-10", "Equal",                "Nearest-10"],
                               [range(3,34,5), "Walking-10", "MoreThan-3",           "Nearest-10"],
                               [range(4,35,5), "Walking-10", "Inputs",               "Nearest-10"],
                               [range(5,36,5), "Walking-10", "Inputs-PerDistance-3", "Nearest-10"]
                              ] for x in l],
                              columns=["Model", "Walking", "Cycling", "Nearest"]).sort_values("Model")

FREQUENCIES = {x:k for k, v in 
               {"A":range(1,6),
                "B":range(6,11),
                "C":range(11,16),
                "D":range(16,21),
                "E":range(21,26),
                "F":range(26,31),
                "G":range(31,36)                
                }.items() for x in v}

def Probability(model, mode, nearest, keys):
    def GetMatrix(name, path = "../ProbabilityData/"):
        return np.load(path + name + ".npy")
    
    def GetName(col):
        return PROBABILITIES.loc[PROBABILITIES["Model"] == model, col].item()
    
    def CheckName(name):
        if name.split("-")[0] == "Inputs":
            name = name.replace("Inputs", "Inputs-" + "-".join(map(str,keys)))
        return name
    
    name = GetName("Nearest" if nearest else mode)
    name = CheckName(name)
    
    return GetMatrix(name)

def PeopleCreation(env, model, steps, date, hour, stations):
    df_frequency = pd.read_csv("../FrequencyData/Frequency.csv", sep=";")
    df_aux = pd.read_csv(f"../SimulationData/Model_{model}-Date_{date}-Hour_{hour}/Aux.csv", sep=";")
    
    def PersonCreation(env, id_station):
        prec, is_holiday, period = df_aux.loc[df_aux["Simulated_timestamp"] <= env.now*H,
                                              ["Prec", "Is_holiday", "Period"]].tail(1).squeeze()        
        Person(env, model, steps, stations, stations[id_station], (is_holiday, prec, period))
        n = df_frequency.loc[(df_frequency["Prec"] == prec) &
                                (df_frequency["Is_holiday"] == is_holiday) &
                                (df_frequency["Period"] == period) &
                                (df_frequency["Id_station"] == id_station),
                                FREQUENCIES[model]].item()
        
        yield env.timeout(Q/n)
        if env.now < steps*H:
            env.process(PersonCreation(env, id_station))
    
    for id_station in stations:
        env.process(PersonCreation(env, id_station))

class Person(object):
    def __init__(self, env, model, steps, stations, station, keys):
        self.env = env
        self.stations = stations
        self.model = model
        self.steps = steps
        self.keys = keys
        
        self.Arrive(station, "Walking")
    
    def Arrive(self, station, mode):
        if self.env.now < self.steps*H:
            if mode == "Walking":
                if station.n_bikes == 0:
                    self.env.process(self.ChangeLocation(station, mode))
                else:
                    station.PickABike()
                    self.env.process(self.ChangeLocation(station, "Cycling"))
                    
            elif mode == "Cycling":
                if station.n_slots == 0:
                    self.env.process(self.ChangeLocation(station, mode, nearest = True))
                else:
                    station.LeaveABike()
    
    def ChangeLocation(self, station, mode, nearest = False):
        prob = Probability(self.model, mode, nearest, self.keys)        
        row = prob[station.id_station - 1]
        next_id_station = np.random.choice(range(len(row)), p = row) + 1
        distance = DISTANCES[mode].loc[str(station.id_station), str(next_id_station)]
        speed = round(SPEED[mode] * (1 + random.random()/10), 2)
        time = round(distance / speed, 2)
        yield self.env.timeout(time)
        self.Arrive(self.stations[next_id_station], mode)