# -*- coding: utf-8 -*-

import AuxiliarFunctions as af
import BikeStations as bs
import People as p
import Evaluation as e

import simpy
import random
import numpy as np
import time

# Frequencies (people per hour)
# A: random (1 - 20)
# B: const. (6)
# C: by period
# D: by is_holiday
# E: by prec
# G: All

# Probabilities (emision prob. from a station)
# E:     Equal 
# W{N}:  Walking{N}; N:{3,5,10,20}
# N{N}:  Nearest{N}
# M{X}:  MoreThan{X}Metres
# I:     Inputs
# IP{X}: InputsPerDistance

# MODEL | FREQ. |   PROB.
#   1   |   A   | E     E     E
#   2   |   A   | W{10} E     N{10}
#   3   |   A   | W{10} M{3}  N{10}
#   4   |   A   | W{10} I     N{10}
#   5   |   A   | W{10} IP{3} N{10}
#   6   |   B   | E     E     E
#   7   |   B   | W{10} E     N{10}
#   8   |   B   | W{10} M{3}  N{10}
#   9   |   B   | W{10} I     N{10}
#   10  |   B   | W{10} IP{3} N{10}
#   11  |   C   | E     E     E
#   12  |   C   | W{10} E     N{10}
#   13  |   C   | W{10} M{3}  N{10}
#   14  |   C   | W{10} I     N{10}
#   15  |   C   | W{10} IP{3} N{10}
#   16  |   D   | E     E     E
#   17  |   D   | W{10} E     N{10}
#   18  |   D   | W{10} M{3}  N{10}
#   19  |   D   | W{10} I     N{10}
#   20  |   D   | W{10} IP{3} N{10}
#   21  |   E   | E     E     E
#   22  |   E   | W{10} E     N{10}
#   23  |   E   | W{10} M{3}  N{10}
#   24  |   E   | W{10} I     N{10}
#   25  |   E   | W{10} IP{3} N{10}
#   26  |   F   | E     E     E
#   27  |   F   | W{10} E     N{10}
#   28  |   F   | W{10} M{3}  N{10}
#   29  |   F   | W{10} I     N{10}
#   30  |   F   | W{10} IP{3} N{10}
#   31  |   G   | E     E     E
#   32  |   G   | W{10} E     N{10}
#   33  |   G   | W{10} M{3}  N{10}
#   34  |   G   | W{10} I     N{10}
#   35  |   G   | W{10} IP{3} N{10}

# Constants
RANDOM_SEED = 343
MODEL = [x+1 for x in range(35)]
#MODEL = [1, 4, 5,
#         6, 7,
#         11, 12, 14,
#         16, 17,
#         21, 22,
#         26, 30,
#         31, 33]
#MODEL = [4, 6, 7, 8, 9, 10, 12, 17, 22, 30, 33]
#MODEL = [11,13,14,15,16,18,19,20]
#MODEL = [21,23,24,25,26,27,28,29,31,32,34,35]
MODEL = [1,2,3,5]
# Steps
SIMULATION_STEPS = 192
# str:"dd-mm-yyyy"
DATES = ["16-12-2022", "08-02-2023", "17-04-2023"]
# int:0-23
#HOURS = [0, 15]
HOURS = [0, 8, 16]

if __name__ == "__main__":
    t0 = time.time()
    
    print("Valenbisi simulation", end="")
    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)
    
    af.DeleteFolder(path = "../", name = "SimulationData")
    af.CreateFolder(path = "../", name = "SimulationData")
    
    for model in MODEL:
        for date in DATES:
            for hour in HOURS:
                if af.CreateFolder(model=model, date=date, hour=hour):
                    print(f"\n\tModel: {model}\tDate: {date}\tHour: {hour}")
                    
                    env = simpy.Environment()
                    
                    stations = bs.CreateStations(env, model, SIMULATION_STEPS, date, hour)
                    if stations is None:
                        print("\tTime not valid")
                        af.DeleteFolder(model=model, date=date, hour=hour)
                    else:
                        print("\tStations created")
                        
                        p.PeopleCreation(env, model, SIMULATION_STEPS, date, hour, stations)
                        env.process(bs.CreateRegister(env, model, SIMULATION_STEPS, date, hour, stations))
                        
                        env.run(until = SIMULATION_STEPS * af.Q + 1)
                        
                        e.CheckModel(model, date, hour)
    
    e.CompareModels()
    
    t1 = time.time()
    print(f"\n\tTotal time: {round((t1-t0)/af.H,4)}mins")