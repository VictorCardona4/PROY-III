# -*- coding: utf-8 -*-

import AuxiliarFunctions as af
import pandas as pd
import os
import plotly.graph_objects as go

M = 10
METRICS = pd.DataFrame([["darkblue", "darkmagenta"],
                        ["cyan", "pink"],
                        ["blue", "magenta"]],
                       index=["Marker", "Vertical", "Horizontal"],
                       columns=["MAE", "MAPE"])
#           E E E      W E N      W M N      W I N      W IP N
COLORS = ["#ffcccc", "#ffffcc", "#ccffcc", "#ccccff", "#ffccff", # A
          "#ff6666", "#ffff66", "#66ff66", "#6666ff", "#ff66ff", # B
          "#ff3333", "#ffff33", "#33ff33", "#3333ff", "#ff33ff", # C
          "#ff0000", "#ffff00", "#00ff00", "#0000ff", "#ff00ff", # D
          "#cc0000", "#cccc00", "#00cc00", "#0000cc", "#cc00cc", # E
          "#990000", "#999900", "#009900", "#000099", "#990099", # F
          "#660000", "#666600", "#006600", "#000066", "#660066"] # G
FAMILY = "Arial"

def GetDataFrames(path):
    def GetDataFrame(bikeType):
        return pd.read_csv(path + f"{bikeType}Bikes.csv", sep=";")
    
    df_real = GetDataFrame("Real")
    df_simulated = GetDataFrame("Simulated")
    
    df = pd.merge(df_real, df_simulated, on=["Simulated_timestamp", "Id_station"], how="left")
    df["Simulated_timestamp"] = list(map(int,df["Simulated_timestamp"]/(af.H*af.Q)))
    df.columns = ["Steps", "Id_station", "Capacity", "Real_bikes", "Latitude", "Longitude", "Simulated_bikes"]
    
    df_metrics = pd.DataFrame(columns = ["Steps", "Id_station"] + list(METRICS.columns) + ["Latitude", "Longitude"])
    for step, group_by_step in df.groupby(by = "Steps"):
        metrics_list = list(Metrics(group_by_step))
        df_metrics.loc[len(df_metrics)] = [step, "Total"] + metrics_list + [None]*2
        print(f"\tStep: {step}", end="")
        for metric_name, metric_result in zip(METRICS, metrics_list):
            print(f"\t{metric_name}: {metric_result}", end="")
        print()
        for id_station, group_by_id_station in group_by_step.groupby(by = "Id_station"):
            df_metrics.loc[len(df_metrics)] = ([step, str(id_station)] + list(Metrics(group_by_id_station)) +
                                               list(group_by_id_station[["Latitude", "Longitude"]].squeeze()))
        
    df_metrics.to_csv(path + "Metrics.csv", sep = ";", index = False)
    return df_metrics

def CreateGlobalDataFrame(path, name):
    df_metrics = pd.DataFrame()
    for folder in os.listdir(path):
        if folder == name:
            continue
        
        df = pd.read_csv(path + folder + "/Metrics.csv", sep=";")
        df.insert(0, "Model", int(folder.split("-")[0].split("_")[1]))
        
        df_metrics = pd.concat([df_metrics, df], axis=0)
    
    df_metrics['Id_station'] = df['Id_station'].apply(lambda x: 0 if x == "Total" else int(x))
    df_metrics = (df_metrics.groupby(["Model", "Steps", "Id_station"])
                  .agg({"MAE": "mean", "MAPE": "mean", "Latitude": "first", "Longitude": "first"})
                  .reset_index())
    
    df_metrics.sort_values(["Model", "Steps", "Id_station"], inplace = True)
    df_metrics['Id_station'] = df_metrics['Id_station'].astype(str).replace('0', 'Total')
    
    df_metrics.to_csv(path + name + "/Metrics.csv", sep = ";", index = False)    
    return df_metrics
    
def Metrics(df):
    N = len(df)    
    dif = abs(df["Real_bikes"] - df["Simulated_bikes"])
    mae = sum(dif)/N
    mape = sum(dif/df["Capacity"])/N * 100 # Modified: Divided by capacity
    return round(mae, 6), round(mape, 6)

def UpdateLayoutAndSave(fig, path, name, title, xtitle, showlegend):
    fig.update_layout(
        title=dict(
            text=f"<b>{title}<b>",
            x = 0.5,
            xanchor="center",
            font=dict(size=5*M)
        ),
        xaxis_title=dict(
            text=f"<b>{xtitle}<b>",
            font=dict(size=3*M)
        ),
        yaxis_title=dict(
            text="<b>Value<b>",
            font=dict(size=3*M)
        ),
        font=dict(
            color='black',
            family=FAMILY
        ),
        plot_bgcolor='darkgrey',
        paper_bgcolor='lightgrey',
        showlegend=showlegend
    )
    
    fig.update_traces(
        hoverlabel=dict(
            font=dict(
                family=FAMILY,
                size=2*M
            )
        )
    )
    
    fig.write_html(path + name + ".html")

def PartialPlot(path, model, date, hour, df):
    for step, grouped_by_step in df.groupby("Steps"):
        if step == df["Steps"].max():
            for metric, colors in METRICS.items():
                fig = go.Figure()
                
                df_sub = grouped_by_step.iloc[1:]
                x, y = df_sub["Id_station"], df_sub[metric]
                
                fig.add_trace(go.Bar(x=x, y=y,
                                     width = 0.11*M,
                                     marker=dict(
                                         color = METRICS.loc["Vertical", metric],
                                         line = dict(width = 0)),
                                     hoverinfo = "none"))
                
                fig.add_trace(go.Scatter(x=x, y=y,
                                         mode='markers',
                                         marker=dict(
                                             color = METRICS.loc["Marker", metric],
                                             size = M),
                                         hovertemplate='Id_%{x}: %{y}',
                                         name = ""))
                
                df_first = grouped_by_step.iloc[0]        
                fig.add_trace(go.Scatter(x=df_sub["Id_station"],
                                         y=[df_first[metric]]*af.N,
                                         mode='lines',
                                         line=dict(color=METRICS.loc["Horizontal", metric],
                                                   width = 0.4*M,
                                                   dash='longdash'),
                                         hovertemplate='Mean: %{y:.4f}',
                                         name = ""))
                
                fig.update_layout(
                    xaxis=dict(
                        dtick = M,
                        tick0 = 6
                    )
                )
                
                UpdateLayoutAndSave(fig=fig,
                                    path=path,
                                    name=f"{metric}-Step-{step}",
                                    title=f"{metric}   Model {model}   Steps {step}   {date} {str(hour).zfill(2)}:00",
                                    xtitle="ID Station",
                                    showlegend=False)
            
def GlobalPlot(path, df):
    df = df.loc[df["Id_station"] == "0.0", ["Model", "Steps"] + list(METRICS.columns)].reset_index()
    
    for metric in METRICS:
        fig = go.Figure()
        
        for model,group_by_model in df.groupby("Model"):
            fig.add_trace(go.Scatter(x=group_by_model["Steps"],
                                     y=group_by_model[metric],
                                     mode='lines+markers',
                                     marker=dict(
                                         color = COLORS[model-1]
                                     ),
                                     line=dict(
                                         color = COLORS[model-1]
                                     ),
                                     hovertemplate='%{y:.4f}',
                                     name = f"M{model}"))
        
        UpdateLayoutAndSave(fig=fig,
                            path=path,
                            name=metric,
                            title=metric + "   All Models",
                            xtitle="Steps",
                            showlegend=True)
        

def CheckModel(model, date, hour):
    path = f"../SimulationData/Model_{model}-Date_{date}-Hour_{hour}/"
        
    df_metrics = GetDataFrames(path)
    
    PartialPlot(path, model, date, hour, df_metrics)

def CompareModels():
    path = "../SimulationData/"
    name = "AllModels"
    
    af.CreateFolder(name=name)
    df_metrics = CreateGlobalDataFrame(path, name)   
    
    GlobalPlot(path + name + "/", df_metrics)

if __name__ == "__main__":
    CompareModels()