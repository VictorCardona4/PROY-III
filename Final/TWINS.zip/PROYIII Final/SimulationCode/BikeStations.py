# -*- coding: utf-8 -*-

import AuxiliarFunctions as af
import simpy
import pandas as pd

def CreateRegister(env, model, steps, date, hour, stations):
    df = pd.DataFrame(columns = ["Simulated_timestamp", "Id_station", "Bikes"])
    for step in range(steps):
        yield env.timeout(af.Q)
        for id_station, station in stations.items():
            df.loc[len(df)] = [env.now * af.H, id_station, station.n_bikes]
        
    df.to_csv(f"../SimulationData/Model_{model}-Date_{date}-Hour_{hour}/SimulatedBikes.csv",
              sep = ";", index = False)
    
    print("\tSimulation finished")

def CreateStations(env, model, steps, date, hour):
    df_stations = af.DataFrameManagement(model, steps, date, hour)
    
    if df_stations is None or len(df_stations) != af.N:
        return None
    
    return {id_station:BikeStation(env, id_station, n_bikes, n_slots)
            for i, (id_station, n_bikes, n_slots) in df_stations.iterrows()}    

class BikeStation(object):
    def __init__(self, env, id_station, n_bikes, n_slots):
        self.env = env
        self.id_station = id_station
        self.n_bikes = n_bikes
        self.n_slots = n_slots
                
        # Creates Bike Station and a bike
        self.bikeStation = simpy.Resource(env, capacity = n_bikes + n_slots)
        
        # Fills with initial number of bikes
        self.bikes = [self.bikeStation.request() for i in range(n_bikes)]
    
    def PickABike(self):
        self.n_bikes -= 1
        self.n_slots += 1
        self.bikeStation.release(self.bikes.pop(0))
    
    def LeaveABike(self):
        self.n_bikes += 1
        self.n_slots -= 1
        self.bikes.append(self.bikeStation.request())
    
    def __repr__(self):
        return ('%3d %2d bikes %2d slots %.2f' %
                (self.id_station, self.n_bikes, self.n_slots, self.env.now))