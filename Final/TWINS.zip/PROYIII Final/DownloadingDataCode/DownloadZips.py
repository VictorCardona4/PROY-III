# -*- coding: utf-8 -*-

# Auxiliar functions
import AuxiliarFunctions as af

# Time management
import time

# Web access and download
import requests
from bs4 import BeautifulSoup
from urllib import request

def DownloadZips():
    # Initial point: Nothing.
    #   Having this code inside a folder named DownloadingDataCode is hardly recommended
    #   New folders will be created at the same level as DownloadingDataCode folder
    # Final point: All zips downloaded in Zips folder
    
    # DownloadZipByWebScrapping function
    def DownloadZipByWebScrapping(link_name):
        print(f"\tDownloading {link_name}")
        try:
            # Web scraping to download the new zip
            zip_path = "../Zips/" + link_name
            url = f"https://github.com/ceferra/valenbici/raw/master/{link_name}"
            
            # Download zip into local
            request.urlretrieve(url, zip_path)
            
        except:
            # If connection fails, wait and try again
            print("\tConnection failed.\n\tEstablishing connection...")
            time.sleep(10)
            DownloadZipByWebScrapping(link_name)        
        
    # Starting time
    t0 = time.time()
    print("Step 1:")
    
    # Creates ValenbisiData and Zips folders
    af.CreateFolder("ValenbisiData")
    af.CreateFolder("Zips")
    
    try:
        zips_register = af.ReadDocument("ZipsRegister")
    except FileNotFoundError:
        zips_register = []
    
    # Web scraping
    url = "https://github.com/ceferra/valenbici"
    result = requests.get(url)
    src = result.content
    soup = BeautifulSoup(src, 'lxml')
    
    # All zips available
    links = soup.find("div", class_="Box mb-3").find_all("a", class_="js-navigation-open Link--primary")
    link_names = [a.get_text() for a in links]
    link_names = [a for a in link_names if a.split(".")[-1] == "zip"]

    # New zips
    new_zips = list(set(link_names) - set(zips_register))
    new_zips.sort(key=lambda x: (x[6:10], x[3:5], x[0:2]))
    
    for i, link_name in enumerate(new_zips):
        DownloadZipByWebScrapping(link_name)  
        # Save the zip is already downloaded in zips register
        zips_register.append(link_name)
    
    af.WriteDocument("ZipsRegister", zips_register)
    
    # Final time
    t1 = time.time()
    print(f"\tDownload zips time: {round(t1-t0,4)}s")   