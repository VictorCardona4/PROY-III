# -*- coding: utf-8 -*-

from AuxiliarFunctions import CreateFolder
import time
import numpy as np
import os
import pandas as pd

N = 276
PATH = "../ProbabilityData/"

def NormaliseRows(m):
    return m / np.sum(m, axis=1, keepdims=True)

def CheckForMatrix(name):
    return os.path.exists(f"{PATH}{name}.npy")

def SaveMatrix(m, name):
    np.save(f"{PATH}{name}.npy", m)

def GetMatrix(name):
    return np.load(PATH + name + ".npy")

def ReadDistancesCsv(name):
    return pd.read_csv(f"../DistancesData/Distances{name}.csv",
                     sep = ";", index_col = "Index", dtype = {"Index":str})

def GetMatrixFromDistanceCsv(name = "Cycling"):
    return np.genfromtxt(f"../DistancesData/Distances{name}.csv", delimiter = ";",
                         dtype = int, skip_header = 1, usecols = range(1, N+1))

def CreateProbMatrix():
    # Initial point:
    # Final point:
        
    # Starting time
    t0 = time.time()
    print("Step 9:")
    
    CreateFolder("ProbabilityData")
    EqualProb()
    for n in [3, 5, 10, 20]:
        WalkingAndNearestProb("Walking", n)
        WalkingAndNearestProb("Nearest", n)
    for x in [0, 3]:
        MoreThanX(x)
        #CrowdedWithDistanceX(x)
    Inputs()
    
    # Final time
    t1 = time.time()
    print(f"\tCreating probability matrix time: {round(t1-t0,4)}s")

def EqualProb():
    name = "Equal"
    if not CheckForMatrix(name):
        m = np.full((N, N), 1, dtype = int)
        np.fill_diagonal(m, 0)
        m = NormaliseRows(m)
        SaveMatrix(m, name)

def WalkingAndNearestProb(name, n):
    if not CheckForMatrix(name):
        df = ReadDistancesCsv("Cycling" if name == "Nearest" else "Walking")
        m = np.zeros((N, N), dtype = int)
        for i, row in df.iterrows():
            s = row.nsmallest(n + 1)
            for j, d in s.items():
                m[int(i)-1, int(j)-1] = d
        m = NormaliseRows(m)
        SaveMatrix(m, f"{name}-{n}")

def MoreThanX(minValue):
    def BinaryByMinDistanceX(minValue):
        name = f"BinaryByDistance{minValue}"
        if not CheckForMatrix(name):
            CYCLING_SPEED = 265 # m/min
            n = GetMatrixFromDistanceCsv()
            n = np.where((n > minValue * 100) & (n < CYCLING_SPEED * 20), 1, 0)
            SaveMatrix(n, name)
    
    BinaryByMinDistanceX(minValue)
    name = f"MoreThan-{minValue}"
    binaryName = f"BinaryByDistance{minValue}"
    if not CheckForMatrix(name):
        m = GetMatrix(binaryName)
        n = GetMatrixFromDistanceCsv()
        m = NormaliseRows(m*n)
        SaveMatrix(m, name)

def Inputs():
    df = pd.read_csv("../ValenbisiData/Movements.csv", sep=";")
    
    for keys, df_grouped in df.groupby(["Is_holiday", "Prec", "Period"]):
        name = "Inputs-" + "-".join(map(str,keys))
        
        if not CheckForMatrix(name):    
            m = np.tile(df_grouped["Inputs"], (N, 1))
            SaveMatrix(NormaliseRows(m), f"{name}")
            
            for x in [0, 3]:
                n = GetMatrix(f"MoreThan-{x}")
                SaveMatrix(NormaliseRows(m*n), f"{name}-PerDistance-{x}")

def CrowdedWithDistanceX(minValue):
    def CreateRatioMatrix():
        name = "CreateRatioMatrix"
        
        if not CheckForMatrix(f"{name}-False-Day"):    
            df = (pd.read_csv("../ValenbisiData/Valenbisi.csv", sep=";")
                  .groupby(["Is_holiday", "Period", "Id_station"])
                  .agg({"Bikes":"sum","Capacity":"sum"})
                  .reset_index())
            
            df["Ratio"] = df["Bikes"] / df["Capacity"]
            
            for (is_holiday, period), df_grouped in df.groupby(["Is_holiday", "Period"]):
                ratio = df_grouped["Ratio"].values
                m = np.tile(ratio, (len(ratio), 1))
                SaveMatrix(m, f"{name}-{is_holiday}-{period}")
    
    CreateRatioMatrix()
    name = f"CrowdedWithDistance{minValue}"
    
    for file in [x for x in os.listdir(PATH) if x.split('-')[0] == "CreateRatioMatrix"]:
        file = file.split(".")[0]
        a, b, c = file.split('-')
        
        m = GetMatrix(file)
        n = GetMatrix(f"BinaryByDistance{minValue}")
        o = GetMatrix(f"MoreThan{minValue}Metres")
        
        p = NormaliseRows(m*n)
        SaveMatrix(p, f"{name}-{b}-{c}")
        
        q = NormaliseRows(m*o)
        SaveMatrix(q, f"{name}PerDistance-{b}-{c}")

if __name__ == "__main__":
    CreateProbMatrix()