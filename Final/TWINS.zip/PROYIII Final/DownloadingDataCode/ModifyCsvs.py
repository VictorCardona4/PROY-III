# -*- coding: utf-8 -*-

### MILLORAR 0 - 0

# Auxiliar functions
import AuxiliarFunctions as af

# Time control
import time
from datetime import datetime

# Path management
import os

# Dataframes and csvs management
import pandas as pd

def ModifyCsvs():
    # Initial point: All csvs in Csvs folder in DownloadingDataCode folder
    # Final point: Valenbisi2 csv in DownloadingDataCode folder
    
    # Starting time
    t0 = time.time()
    print("Step 5:")
    
    # Dictionary holidays from json
    holidays = af.ReadDocument("Holidays")
    weather = af.ReadDocument("Weather")
    
    # All csvs available
    csvs_path = "../Csvs/"
    files = [f for f in os.listdir(csvs_path)]
    files.sort(key=lambda x: (x[16:20], x[13:15], x[10:12], x[21:23], x[24:26]))
    
    # Dataframe creation and constants
    df = pd.DataFrame()
    NEW_COLUMNS = {"number_": "Id_station",
                   "available": "Bikes",
                   "free": "Slots",
                   "total": "Capacity",
                   "geo_point_2d": "Point"}
    PREC_LIMIT = 5
    
    for csv in files:
        # Time register
        date, (hour, quarter) = csv[10:20], csv[21:26].split("-")
        
        # Dataframe from csv
        df_q = pd.read_csv(csvs_path + csv, delimiter=";")
        # Columns selection and rename
        df_q = df_q[NEW_COLUMNS.keys()]
        df_q.rename(columns = NEW_COLUMNS, inplace=True)
        df_q.sort_values(by="Id_station", inplace=True)
        
        # Columns addition
        strptime = datetime.strptime(f"{date} {hour}:{quarter}", "%d-%m-%Y %H:%M")
        weekday = strptime.strftime("%a")
        
        # Columns addition
        # Before data exploration
        """
        df_q.insert(0, "Date", date)
        df_q.insert(1, "Weekday", weekday)
        df_q.insert(2, "Is_holiday", weekday in ["Sat", "Sun"] or date in holidays[date[6:]])
        for i, x in enumerate(WEATHER_VARIABLES):
            df_q.insert(3 + i, x, weather[date][x])
        df_q.insert(len(WEATHER_VARIABLES) + 3, "Hour", int(hour))        
        df_q.insert(len(WEATHER_VARIABLES) + 4, "Quarter", int(quarter))
        df_q.insert(len(WEATHER_VARIABLES) + 5, "Timestamp", int(strptime.timestamp()))
        df_q.insert(len(df_q.columns) - 1, "Predicted", df_q["Bikes"] + df_q["Slots"] == 0)
        """
        # After data exploration -> Remove some variables
        df_q.insert(0, "Date", date)
        df_q.insert(1, "Is_holiday", weekday in ["Sat", "Sun"] or date in holidays[date[6:]])
        df_q.insert(2, "Prec", weather[date] > PREC_LIMIT)
        df_q.insert(3, "Hour", int(hour))
        df_q.insert(4, "Quarter", int(quarter))
        df_q.insert(5, "Timestamp", int(strptime.timestamp()))
        df_q.insert(len(df_q.columns) - 1, "Predicted", df_q["Bikes"] + df_q["Slots"] == 0)        
        
        # Dataframes union
        df = pd.concat([df, df_q], axis=0)
        
        # Csv delete
        os.remove(csvs_path + csv)
    
    # Dataframe to csv and folder delete
    if len(df) != 0:
        # Include Period
        bins, labels = [-0.5, 0.5, 7.5, 20.5, 23.5], ["Twelve", "Night", "Day", "Evening"]        
        df.insert(4, "Period", pd.cut(df["Hour"],
                                      bins=bins, labels=labels))        
        # Transform Point
        df[["Latitude", "Longitude"]] = df["Point"].str.split(",", expand=True)
        del df["Point"]
        
        df.to_csv("../ValenbisiData/Valenbisi2.csv", sep = ";", index = False)
    os.rmdir(csvs_path)
    
    # Final time --> 2.5s/day
    t1 = time.time()
    print(f"\tModification csvs time: {round(t1-t0,4)}s")
    
    return df