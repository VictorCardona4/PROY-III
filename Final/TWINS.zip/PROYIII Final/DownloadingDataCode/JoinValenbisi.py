# -*- coding: utf-8 -*-

# Time control
import time

# Path management
import os

# Dataframes and csvs management
import pandas as pd

def JoinValenbisi():
    # Initial point: 1 or 2 Valenbisi csvs in DownloadingDataCode folder
    # Final point: 1 Valenbisi csv in DownloadingDataCode folder
    
    def ValenbisiFile(name):
        return f"../ValenbisiData/Valenbisi{name}.csv"
    
    def GetDf(name):
        return pd.read_csv(ValenbisiFile(name), delimiter=";")
    
    def Predict():
        # Calculate 0 bikes and 0 slots registers
        missingStations = sorted(df.loc[df["Predicted"] == True, "Id_station"].unique())
        for station in missingStations:
            capacity = int(df.loc[(df["Id_station"] == station), "Capacity"].mean())
            try:
                bikes = int(round(df.loc[(df["Id_station"] == station) &
                                        (df["Predicted"] == False),
                                        "Bikes"].mean(), 0))
            except ValueError:
                bikes = int(capacity / 2)
            
            df.loc[(df["Id_station"] == station) &
                   (df["Predicted"] == True),
                   ["Bikes", "Slots"]] = (bikes, capacity - bikes)
        
        df.to_csv(ValenbisiFile(""), sep = ";", index = False)        
    
    # Starting time
    t0 = time.time()
    print("Step 6:")
    
    # Option 1: Valenbisi 1 doesn't exist. Valenbisi 2 exists
    # Option 2: Valenbisi 1 exists. Valenbisi 2 doesn't exist
    # Option 3: Valenbisi 1 exists. Valenbisi 2 exists
    
    if os.path.exists(ValenbisiFile("")):
        if os.path.exists(ValenbisiFile("2")):
            # Option 3
            df = GetDf("")
            df2 = GetDf("2")
            
            # Dataframes union
            df = pd.concat([df, df2], axis=0)
            os.remove(ValenbisiFile("2"))
            Predict()
    else:
        # Option 1
        os.rename(ValenbisiFile("2"), ValenbisiFile(""))
        df = GetDf("")
        Predict()
    
    # Final time
    t1 = time.time()
    print(f"\tJoining valenbisi time: {round(t1-t0,4)}s")