# -*- coding: utf-8 -*-

# Auxiliar functions
import AuxiliarFunctions as af

# Time management
import time

# Path management
import os

# Web access and download
import requests
from bs4 import BeautifulSoup

def DownloadHolidays():
    # Initial point: All zips downloaded in Zips folder
    # Final point: Holidays json in DownloadingDataCode folder
        
    # Starting time
    t0 = time.time()
    print("Step 2:")
    
    # All zips downloaded
    zip_files = [f for f in os.listdir("../Zips/") if f.split(".")[-1] == "zip"]
    years = set(map(int, [f[6:10] for f in zip_files]))
    
    try:
        holidays = af.ReadDocument("Holidays")
        if years - set(map(int,holidays.keys())) != set():
            raise Exception
    except:
        holidays = {}
        for year in years:
            holidays[year] = []
            
            # Web scraping
            url = f"https://www.calendarioslaborales.com/calendario-laboral-valencia-{year}.htm"
            result = requests.get(url)
            src = result.content
            soup = BeautifulSoup(src, 'lxml')
            
            months = soup.find("div", id="wrapIntoMeses").find_all("div", class_="mes")
            for m, month in enumerate(months):
                for t in ["N", "R", "P"]:
                    for holiday in [h.get_text() for h in month.find_all("td", class_=f"cajaFestivo{t}")]:
                        holidays[year].append(f"{str(holiday).zfill(2)}-{str(m+1).zfill(2)}-{year}")
            
            holidays[year].sort(key=lambda x: (x[6:10], x[3:5], x[0:2]))
        
        af.WriteDocument("Holidays", holidays)
    
    # Final time
    t1 = time.time()
    print(f"\tDownload holidays time: {round(t1-t0,4)}s")