# -*- coding: utf-8 -*-

# Auxiliar functions
import AuxiliarFunctions as af

# Time management
import time

# Path management
import os

# Zip mamagement
from zipfile import ZipFile

def ExtractDataFromZips():
    # Initial point: All zips downloaded in Zips folder
    #                DownloadingDataCode created with registers
    # Final point: All csvs in FirstCsvs folder
    
    # Starting time
    t0 = time.time()
    print("Step 4:")
    
    # Creates the Csvs folder
    af.CreateFolder("Csvs")
    zips_path = "../Zips/"
    
    # Days to delete since weather is not available
    zips_register = set(af.ReadDocument("ZipsRegister"))
    weather = set(af.ReadDocument("Weather"))
    delete = zips_register - {x + ".zip" for x in weather}
    
    # Delete from Zips folder and ZipsRegister json
    for x in delete:
        zips_register.remove(x)
        os.remove(zips_path + x)    
    
    # All zips downloaded
    zip_files = [f for f in os.listdir(zips_path) if f.split(".")[-1] == "zip"]
    zip_files.sort(key=lambda x: (x[6:10], x[3:5], x[0:2]))
    
    # Csvs extraction from the zips
    for zip_file in zip_files:
        # Extract all csvs from a zip
        ZipFile(zips_path + zip_file).extractall("../Csvs/")
        os.remove(zips_path + zip_file)
    
    # Delete Zips folder
    os.rmdir(zips_path)
    
    # Save new registers data
    zips_register = list(zips_register)
    zips_register.sort(key=lambda x: (x[6:10], x[3:5], x[0:2]))
    af.WriteDocument("ZipsRegister", zips_register)
    af.WriteDocument("WeatherRegister", zips_register[-1])

    # Final time
    t1 = time.time()
    print(f"\tExtraction data from zips time: {round(t1-t0,4)}s")