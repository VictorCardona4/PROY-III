# -*- coding: utf-8 -*-

from AuxiliarFunctions import CreateFolder
import time
import pandas as pd
import random
from itertools import combinations
import string

KEY_COLUMNS = ["Is_holiday", "Prec", "Period", "Id_station"]
COLUMNS = list(string.ascii_uppercase)

def CreateCombinations():
    combinations_list = []

    for r in range(1, len(KEY_COLUMNS) + 1):
        combinations_list.extend(combinations(KEY_COLUMNS, r))

    return [list(comb) for comb in combinations_list]

def CreateInputsOutputsCsv():
    path = "../ValenbisiData/"
    df = pd.read_csv(path + "Valenbisi.csv", sep=";")[KEY_COLUMNS + ["Timestamp", "Bikes"]]
    
    df_movements = pd.DataFrame(columns = KEY_COLUMNS + ["Inputs", "Outputs"])
    for i, (keys, df_grouped) in enumerate(df.groupby(KEY_COLUMNS)):
        timestamp, bikes = map(list, [df_grouped["Timestamp"], df_grouped["Bikes"]])
        inputs, outputs = 0, 0
        timestamp1, bikes1 = 0, 0
        ci, co = 1, 1
        for timestamp2, bikes2 in zip(timestamp, bikes):
            if timestamp2 == timestamp1 + 900:
                if bikes2 > bikes1:
                    co += 1
                    outputs += bikes2 - bikes1
                elif bikes2 < bikes1:
                    ci += 1
                    inputs += bikes1 - bikes2
                    
            timestamp1, bikes1 = timestamp2, bikes2
        
        df_movements.loc[i] = list(keys) + [inputs/ci, outputs/co]
        
    df_movements.to_csv(path + "Movements.csv", sep=";", index = False)    
    return df_movements

def CreateFreqCsv():
    # Initial point:
    # Final point:
        
    # Starting time
    t0 = time.time()
    print("Step 8:")
    
    random.seed(4)
    CreateFolder("FrequencyData")
    
    df = CreateInputsOutputsCsv()
    N = len(df)
    
    df[COLUMNS[0]] = [random.random()*max(df["Outputs"]) for x in range(N)]
    df[COLUMNS[1]] = df["Outputs"].mean()
    
    for i, column in enumerate(KEY_COLUMNS):
        d = {k:v["Outputs"] for k,v in 
             df.groupby(column).agg({"Outputs":"mean"}).to_dict(orient='index').items()
             }
        
        df[COLUMNS[i+2]] = df.apply(lambda x: d.get((x[column]), None), axis=1)
    df[COLUMNS[i+3]] = df["Outputs"] + 0.001
        
    df.to_csv("../FrequencyData/Frequency.csv", sep=";", index=False)
    
    # Final time
    t1 = time.time()
    print(f"\tCreating frequencies matrix time: {round(t1-t0,4)}s")
    
    return df

if __name__ == "__main__":
    df = CreateFreqCsv()