# -*- coding: utf-8 -*-

# File system management
import os

# Json data management
import json

import numpy as np

# Create folder function
def CreateFolder(name):
    try:
        # If the folder doesn't exist
        os.makedirs(f"../{name}")
        print(f"\t{name} folder created!")
    except FileExistsError:
        pass

# Read document function
def ReadDocument(name, path = "../ValenbisiData/", extension = ".json"):
    with open(path + name + extension, "r") as readerFile:
        return json.load(readerFile)

# Write document function
def WriteDocument(name, doc, path = "../ValenbisiData/", extension = ".json"):
    with open(path + name + extension, 'w') as writerFile:
        json.dump(doc, writerFile)

# Reverse data function
def ReverseDate(s, hasExtension = False):
    if hasExtension:
        s = s.split('.')[0]
    return '-'.join(s.split('-')[::-1])