# -*- coding: utf-8 -*-

# Auxiliar functions
import AuxiliarFunctions as af

# Time management
import time

# Json data management
import json

# API management
import requests

# API credentials
QUERYSTRING = {"api_key":"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhbmdlbGFhcnRlYWdhZG9AZ21haWwuY29tIiwianRpIjoiZTY0N2U1NjAtNTI2Ni00Zjc1LTkxMmEtOWIwMjRjNzlkMDczIiwiaXNzIjoiQUVNRVQiLCJpYXQiOjE2NzY5MTUwODcsInVzZXJJZCI6ImU2NDdlNTYwLTUyNjYtNGY3NS05MTJhLTliMDI0Yzc5ZDA3MyIsInJvbGUiOiIifQ.Ph58hhRgjPAoL3e3qpFX-5aHonQ2D59L0gaVYh5RU2k"}
HEADERS = {"cache-control": "no-cache"}
#VARIABLES = {"T_min":"tmin", "T_mean":"tmed", "T_max":"tmax",
#             "Prec":"prec",
#             "Vel_mean": "velmedia", "Vel_max": "racha"}
# Tras comprobar que únicamente la precipitación afecta, se implementará directamente

def DownloadWeather():
    # Initial point: All zips downloaded in Zips folder
    #                DownloadingDataCode created with registers
    # Final point: Weather and WeatherRegister json in DownloadingDataCode folder
    
    def StringToFloat(s):
        try:
            return float(s.replace(',', '.'))
        except ValueError:
            print(f"\tCouldn't converted {s}")
            return None
        except AttributeError:
            print("\tMissing field")
            return None
    
    # Starting time
    t0 = time.time()
    print("Step 3:")
    
    # Maxium of days the API can support
    N_MAX = 30
    
    zips_register = af.ReadDocument("ZipsRegister")
    
    try:
        weather_register = af.ReadDocument("WeatherRegister")
        zips_register = zips_register[zips_register.index(weather_register)+1:]
    except FileNotFoundError:
        weather_register = zips_register[0]
        zips_register = zips_register[zips_register.index(weather_register):]
    weather_register = []
    
    # Days to download weather
    if zips_register != []:
        for i, x in enumerate(zips_register):
            if i%N_MAX == 0:
                weather_register.append([x, None])
            elif i%N_MAX == N_MAX - 1:
                weather_register[-1][1] = x
        
        if weather_register[-1][1] == None:
            weather_register[-1][1] = zips_register[-1]
        
        try:
            weather = af.ReadDocument("Weather")
        except FileNotFoundError:
            weather = {}
        
        # AEMET request -> Response: url
        for fecha_ini, fecha_fin in weather_register:
            url = ("https://opendata.aemet.es/opendata/api/valores/climatologicos/diarios/datos/"+
                   f"fechaini/{af.ReverseDate(fecha_ini, True)}T00%3A00%3A00UTC/"+
                   f"fechafin/{af.ReverseDate(fecha_fin, True)}T00%3A00%3A00UTC/"+
                   "todasestaciones")
            response = json.loads(requests.request("GET", url, headers=HEADERS, params=QUERYSTRING).text)
            
            if response["estado"] == 200:
                # Request to the url
                response = requests.request("GET", response["datos"])
                
                # Save Valencia data
                for weather_station in json.loads(response.text):
                    if weather_station["indicativo"] == "8416Y":
                        if "prec" not in weather_station:
                            prec = weather[list(weather.keys())[-1]]
                        else:
                            prec = float(weather_station["prec"].replace(',', '.'))
                        weather[af.ReverseDate(weather_station["fecha"])] = prec
                af.WriteDocument("Weather", weather)
    
    # Final time
    t1 = time.time()
    print(f"\tDownload weather time: {round(t1-t0,4)}s")