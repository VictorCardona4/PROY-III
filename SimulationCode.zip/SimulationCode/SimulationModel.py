# -*- coding: utf-8 -*-

import AuxiliarFunctions as af
import BikeStations as bs
import People as p
import Evaluation as e

import simpy
import random
import numpy as np
import time

# Frequencies (people per hour)
# A: random (1 - 20)
# B: const. (6)
# C: by period
# D: by is_holiday
# E: by prec

# Probabilities (emision prob. from a station)
# E: Equal 
# W: Walking
# N: Nearest
# L: Less30MinsDuration

# MODEL | FREQ. | PROB.
#   1   |   A   | E E E
#   2   |   A   | W L N
#   3   |   B   | W L N
#   4   |   C   | W L N
#   5   |   D   | W L N
#   6   |   E   | W L N

# Constants
RANDOM_SEED = 343
MODEL = [1, 2, 3, 4, 5, 6]
#MODEL = [1]
# Steps
SIMULATION_STEPS = 8
# str:"dd-mm-yyyy"
DATES = ["05-12-2022", "24-03-2023"]
# int:0-23
HOURS = [8, 20]
#HOURS = [8]

if __name__ == "__main__":
    t0 = time.time()
    
    print("Valenbisi simulation", end="")
    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)
    
    af.CreateFolder(path = "..", name = "SimulationData")
    
    for model in MODEL:
        for date in DATES:
            for hour in HOURS:
                if af.CreateFolder(model=model, date=date, hour=hour):
                    print(f"\n\tModel: {model}\tDate: {date}\tHour: {hour}")
                    
                    env = simpy.Environment()
                    
                    stations = bs.CreateStations(env, model, SIMULATION_STEPS, date, hour)
                    if stations is None:
                        print("\tTime not valid")
                        af.DeleteFolder(model, date, hour)
                    else:
                        print("\tStations created")
                        
                        p.PeopleCreation(env, model, SIMULATION_STEPS, date, hour, stations)
                        env.process(bs.CreateRegister(env, model, SIMULATION_STEPS, date, hour, stations))
                        
                        env.run(until = SIMULATION_STEPS * af.Q + 1)
                        
                        e.CheckModel(model, date, hour)
    
    e.CompareModels()
    
    t1 = time.time()
    print(f"\n\tTotal time: {round(t1-t0,4)}s")