# -*- coding: utf-8 -*-

import os
import pandas as pd
from datetime import datetime
import shutil

N = 276
H = 60
Q = 15

def CreateFolder(model = None, date = None, hour = None,
                 path = "../SimulationData/", name = None):
    if name is None:
        name = f"Model_{model}-Date_{date}-Hour_{hour}"
    try:
        os.makedirs(path + name)
        return True
    except FileExistsError:
        return False

def DeleteFolder(model, date, hour):
    shutil.rmtree(f"../SimulationData/Model_{model}-Date_{date}-Hour_{hour}")

def DataFrameManagement(model, steps, date, hour):
    path = f"../SimulationData/Model_{model}-Date_{date}-Hour_{hour}/"
    
    initialTimestamp = int(datetime.strptime(f"{date} {str(hour).zfill(2)}", '%d-%m-%Y %H').timestamp())
    finalTimestamp = initialTimestamp + steps * 15 * 60
    
    df = pd.read_csv("../ValenbisiData/Valenbisi.csv", delimiter=";")
    df = df.loc[(df["Timestamp"] >= initialTimestamp) &
                (df["Timestamp"] <= finalTimestamp)].reset_index(drop = True)
    df["Simulated_timestamp"] = df["Timestamp"] - initialTimestamp
    
    df_stations = df.loc[df["Simulated_timestamp"] == 0,
                         ["Id_station", "Bikes", "Slots"]]
    
    df_real_bikes = df.loc[df["Simulated_timestamp"] > 0,
                           ["Simulated_timestamp", "Id_station", "Capacity", "Bikes"]]
    df_real_bikes.to_csv(path + "RealBikes.csv", sep = ";", index = False)
    
    if len(df_real_bikes) == 0:
        return None
    
    df_aux = df[["Simulated_timestamp", "Prec", "Is_holiday", "Period"]].drop_duplicates()
    df_aux.to_csv(path + "Aux.csv", sep = ";", index = False)
    
    return df_stations