# -*- coding: utf-8 -*-

from AuxiliarFunctions import H
import random
import numpy as np
import pandas as pd

SPEED = {"Walking": 92, "Cycling": 265} # m/min
DISTANCES = {k:pd.read_csv(f"../DistancesData/Distances{k}.csv",
                           sep = ";",
                           index_col = "Index",
                           dtype = {"Index":str}) for k in SPEED}

def Probability(model, mode, nearest):
    if mode == "Walking":
        if model == 1:
            return np.load("../ProbabilityData/Equal.npy")
        if model >= 2:
            return np.load("../ProbabilityData/Walking.npy")
    if mode == "Cycling":
        if model == 1:
            return np.load("../ProbabilityData/Equal.npy")
        if model >= 2:
            if nearest:
                return np.load("../ProbabilityData/Nearest.npy")
            return np.load("../ProbabilityData/Less30MinsDuration.npy")

def Frequency(model):
    if model in [1, 2]:
        return "A"
    if model == 3:
        return "B"
    if model == 4:
        return "C"
    if model == 5:
        return "D"
    if model == 6:
        return "E"    

def PeopleCreation(env, model, steps, date, hour, stations):
    df_frequency = pd.read_csv("../FrequencyData/Frequency.csv", sep=";")
    df_aux = pd.read_csv(f"../SimulationData/Model_{model}-Date_{date}-Hour_{hour}/Aux.csv", sep=";")
    
    def PersonCreation(env, id_station):
        Person(env, model, stations, stations[id_station])
        
        prec, is_holiday, period = df_aux.loc[df_aux["Simulated_timestamp"] <= env.now*H,
                                              ["Prec", "Is_holiday", "Period"]].tail(1).squeeze()
        freq = df_frequency.loc[(df_frequency["Prec"] == prec) &
                                (df_frequency["Is_holiday"] == is_holiday) &
                                (df_frequency["Period"] == period) &
                                (df_frequency["Id_station"] == id_station),
                                Frequency(model)].item()
        
        yield env.timeout(H/freq)
        if env.now < steps*H:
            env.process(PersonCreation(env, id_station))
    
    for id_station in stations:
        env.process(PersonCreation(env, id_station))

class Person(object):
    def __init__(self, env, model, stations, station):
        self.env = env
        self.stations = stations
        self.model = model
        
        env.process(self.Arrive(station, "Walking"))
    
    def Arrive(self, station, mode):
        if mode == "Walking":
            if station.n_bikes == 0:
                self.env.process(self.ChangeLocation(station, mode))
            else:
                station.PickABike()
                yield self.env.timeout(1)
                self.env.process(self.ChangeLocation(station, "Cycling"))
                
        elif mode == "Cycling":
            if station.n_slots == 0:
                self.env.process(self.ChangeLocation(station, mode, nearest = True))
            else:
                yield self.env.timeout(0.2)
                station.LeaveABike()
    
    def ChangeLocation(self, station, mode, nearest = False):        
        prob = Probability(self.model, mode, nearest)        
        row = prob[station.id_station - 1]
        next_id_station = np.random.choice(range(len(row)), p = row) + 1
        distance = DISTANCES[mode].loc[str(station.id_station), str(next_id_station)]
        speed = round(SPEED[mode] * (1 + random.random()/10), 2)
        time = round(distance / speed, 2)
        yield self.env.timeout(time)
        self.env.process(self.Arrive(self.stations[next_id_station], mode))